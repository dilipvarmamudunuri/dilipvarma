from django.contrib import admin
from performance.models import AddEmployee
from performance.models import FeedbackForm
# Register your models here.
admin.site.register(AddEmployee)
admin.site.register(FeedbackForm)
